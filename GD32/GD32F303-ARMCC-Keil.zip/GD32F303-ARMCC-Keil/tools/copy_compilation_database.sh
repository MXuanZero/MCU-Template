proj_path=$(pwd)
cp $proj_path/uvision/.vscode/c_cpp_properties.json $proj_path/uvision/.vscode/keil-assistant.log $proj_path/uvision/.vscode/uv4.log $proj_path/.vscode